# Payment integration boundary

Real payments are intentionally disabled. The app currently supports only non-cash demo points. Do not use demo points for wagers, cash prizes, or withdrawals.

Before a legitimate payment integration can be implemented:
1. Confirm the product and business model is lawful in the target market and allowed by the payment provider. This starter is for casual non-betting games.
2. The business owner must obtain an approved merchant account directly from the provider.
3. Use the provider's official server-side checkout API; never trust a browser redirect as proof of payment.
4. Verify signed webhooks on the server, check amount/currency/order identity, and make event processing idempotent.
5. Keep API secrets in environment variables or a secrets manager. Never commit them or expose them in browser JavaScript.
6. Implement refunds, reconciliation, audit logs, error handling, privacy notices, and sandbox tests before production.
7. Keep the payment feature disabled until all tests and compliance checks pass.

`POST /api/payments/create` is a safe placeholder and does not initiate a transaction. Setting `PAYMENTS_ENABLED=true` does not enable a provider adapter; it returns HTTP 501 until one is actually implemented. Do not change this behavior to fake a successful payment.
