require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const session = require('express-session');
const SQLiteStore = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
if (process.env.NODE_ENV === 'production' && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) {
  throw new Error('Production requires SESSION_SECRET with at least 32 characters.');
}
const db = new SQLiteStore(path.join(__dirname, '..', 'playnova.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS ledger (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL,
 amount INTEGER NOT NULL,
 kind TEXT NOT NULL,
 note TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'demo',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

const countUsers = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
if (!countUsers && process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
  const hash = bcrypt.hashSync(process.env.ADMIN_PASSWORD, 12);
  db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)')
    .run('Site Admin', process.env.ADMIN_EMAIL.toLowerCase(), hash, 'admin');
  console.log('Initial admin created from environment settings. Change the password after first login.');
}

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '20kb' }));
app.use(express.urlencoded({ extended: false, limit: '20kb' }));
app.use(session({
  name: 'playnova.sid',
  secret: process.env.SESSION_SECRET || 'dev-only-change-this-session-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 1000 * 60 * 60 * 8 }
}));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: true, legacyHeaders: false }));
app.use('/api/auth/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 12, standardHeaders: true, legacyHeaders: false }));

const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, role: u.role });
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'প্রথমে লগইন করুন।' });
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'লগইন প্রয়োজন।' });
  const u = db.prepare('SELECT id, role FROM users WHERE id=?').get(req.session.userId);
  if (!u || u.role !== 'admin') return res.status(403).json({ error: 'শুধু অ্যাডমিনের জন্য।' });
  next();
}
function walletBalance(userId) {
  return db.prepare("SELECT COALESCE(SUM(CASE WHEN kind='credit' THEN amount ELSE -amount END),0) AS balance FROM ledger WHERE user_id=? AND status='demo'").get(userId).balance;
}

app.get('/api/health', (req, res) => res.json({ ok: true, app: 'PlayNova BD', payments: process.env.PAYMENTS_ENABLED === 'true' ? 'provider-not-configured' : 'disabled' }));
app.get('/api/me', (req, res) => {
  if (!req.session.userId) return res.json({ user: null });
  const u = db.prepare('SELECT id,name,email,role FROM users WHERE id=?').get(req.session.userId);
  if (!u) { req.session.destroy(() => {}); return res.json({ user: null }); }
  res.json({ user: publicUser(u), balance: walletBalance(u.id) });
});
app.post('/api/auth/register', async (req, res) => {
  const name = String(req.body.name || '').trim().slice(0, 60);
  const email = String(req.body.email || '').trim().toLowerCase().slice(0, 190);
  const password = String(req.body.password || '');
  if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 10) {
    return res.status(400).json({ error: 'নাম, সঠিক ইমেইল এবং অন্তত ১০ অক্ষরের পাসওয়ার্ড দিন।' });
  }
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(name, email, hash);
    req.session.regenerate((err) => {
      if (err) return res.status(500).json({ error: 'অ্যাকাউন্ট তৈরি হয়েছে, কিন্তু সেশন শুরু করা যায়নি। আবার লগইন করুন।' });
      req.session.userId = result.lastInsertRowid;
      res.json({ user: { id: result.lastInsertRowid, name, email, role: 'user' }, balance: 0 });
    });
  } catch (e) {
    if (String(e.code).includes('SQLITE_CONSTRAINT')) return res.status(409).json({ error: 'এই ইমেইলে অ্যাকাউন্ট আছে।' });
    res.status(500).json({ error: 'অ্যাকাউন্ট তৈরি করা যায়নি।' });
  }
});
app.post('/api/auth/login', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const u = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!u || !(await bcrypt.compare(password, u.password_hash))) return res.status(401).json({ error: 'ইমেইল বা পাসওয়ার্ড সঠিক নয়।' });
  req.session.regenerate((err) => {
    if (err) return res.status(500).json({ error: 'লগইন করা যায়নি।' });
    req.session.userId = u.id;
    res.json({ user: publicUser(u), balance: walletBalance(u.id) });
  });
});
app.post('/api/auth/logout', (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get('/api/wallet', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT id,amount,kind,note,status,created_at FROM ledger WHERE user_id=? ORDER BY id DESC LIMIT 50').all(req.session.userId);
  res.json({ balance: walletBalance(req.session.userId), transactions: rows });
});
// Demo credits only. They are not money and cannot be withdrawn or converted into prizes.
app.post('/api/wallet/demo-credit', requireAuth, (req, res) => {
  const amount = Number(req.body.amount);
  if (![100, 500, 1000].includes(amount)) return res.status(400).json({ error: 'শুধু ১০০, ৫০০ বা ১০০০ ডেমো পয়েন্ট যোগ করা যাবে।' });
  db.prepare("INSERT INTO ledger(user_id,amount,kind,note,status) VALUES(?,?,?,?, 'demo')")
    .run(req.session.userId, amount, 'credit', 'ডেমো পয়েন্ট — বাস্তব টাকা নয়');
  res.json({ balance: walletBalance(req.session.userId), message: 'ডেমো পয়েন্ট যোগ হয়েছে।' });
});
// A safe payment integration boundary: no fake success, no personal-number transfers.
app.post('/api/payments/create', requireAuth, (req, res) => {
  if (process.env.PAYMENTS_ENABLED !== 'true') return res.status(503).json({ error: 'বাস্তব পেমেন্ট এখনো চালু নয়। অনুমোদিত মার্চেন্ট অ্যাকাউন্ট ও সার্ভার-সাইড গেটওয়ে ইন্টিগ্রেশন প্রয়োজন।' });
  return res.status(501).json({ error: 'পেমেন্ট গেটওয়ে অ্যাডাপ্টার এখনো যুক্ত করা হয়নি। অফিসিয়াল API ও webhook যাচাই যোগ না করা পর্যন্ত পেমেন্ট বন্ধ থাকবে।' });
});
app.get('/api/admin/summary', requireAdmin, (req, res) => {
  const users = db.prepare('SELECT id,name,email,role,created_at FROM users ORDER BY id DESC LIMIT 100').all();
  const tx = db.prepare('SELECT l.id,l.user_id,u.email,l.amount,l.kind,l.note,l.status,l.created_at FROM ledger l JOIN users u ON u.id=l.user_id ORDER BY l.id DESC LIMIT 100').all();
  res.json({ userCount: db.prepare('SELECT COUNT(*) AS n FROM users').get().n, users, transactions: tx });
});
app.get('*', (req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));
app.listen(PORT, () => console.log(`PlayNova BD running at http://localhost:${PORT}`));
